红色：LED0闪
绿色：LED1闪
蓝色：两个灯同时闪

P4（USART3_TX）—> PA10（USART1_RX）
P5（USART3_RX）—> PA9（USART1_TX）
GND共地

STM32程序对应颜色识别

二维码程序需要根据自己设置的串口进行编程。