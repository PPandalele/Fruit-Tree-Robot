#include "openmv.h"
#include "led.h"

int openmv[6];//stm32������������

int i=0;

void Openmv_Receive_Data(int16_t data)//����Openmv������������
{
	static u8 state = 0;
	if(state==0&&data==0xA3)
	{
		state=1;
		openmv[0]=data;
	}
	else if(state==1&&data==0xA3)
	{
		state=2;
		openmv[1]=data;
	}
	else if(state==2)
	{
		state=3;
		openmv[2]=data;
	}
	else if(state==3)
	{
		state = 4;
		openmv[3]=data;
    LED0=!LED0;
	}    
	else
		{
			state = 0;
            for(i=0;i<5;i++)
            {
                openmv[i]=0x00;
            }
		}
}


